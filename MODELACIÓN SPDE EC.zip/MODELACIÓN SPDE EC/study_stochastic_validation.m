clear
close all
clc

fprintf('\n');
fprintf('====================================\n');
fprintf('VALIDACION ESTOCASTICA\n');
fprintf('====================================\n');


%% PARÁMETROS

L = 1;

T = 0.5;

alpha = 1;

dx = 0.01;

dt = 1e-4;

sigma = 0.20;

Nmc = 500;


%% MALLA

grid = build_grid(L,T,dx,dt);


%% CONDICIÓN INICIAL

U0 = sin(pi*grid.x);


%% OPERADOR

Ah = assemble_Ah( ...
        grid.Nx,...
        grid.dx,...
        alpha);


%% SOLUCIÓN DETERMINISTA

detU = solver_deterministic_CN( ...
            U0,...
            Ah,...
            grid);


%% MONTE CARLO

opts.store_all = false;

opts.rngSeed = 1;

opts.parallel = false;


stats = montecarlo_runner( ...
            U0,...
            Ah,...
            grid,...
            sigma,...
            Nmc,...
            opts);


%% ERROR EN LA MEDIA

errorL2 = norm( ...
            stats.mean(:,end) ...
          - detU(:,end),2);


errorMax = max( ...
            abs(stats.mean(:,end) ...
          - detU(:,end)));


fprintf('\n');

fprintf('====================================\n');
fprintf('RESULTADOS\n');
fprintf('====================================\n');

fprintf('Nmc = %d\n',Nmc);

fprintf('sigma = %.3f\n',sigma);

fprintf('\n');

fprintf('Error L2 = %.6e\n',errorL2);

fprintf('Error Max = %.6e\n',errorMax);

fprintf('====================================\n');


%% FIGURA

figure

plot(grid.x,detU(:,end), ...
    'k','LineWidth',2)

hold on

plot(grid.x,stats.mean(:,end), ...
    'r--','LineWidth',2)

grid on

legend( ...
    'Determinista',...
    'Media Monte Carlo')

xlabel('x')

ylabel('u(x,T)')

title('Validación estocástica')