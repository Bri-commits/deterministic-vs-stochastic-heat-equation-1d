function grid = build_grid(L, T, dx, dt, verbose)
%% ========================================================================
% 0. OPCIÓN DE IMPRESIÓN
% ========================================================================

if nargin < 5

    verbose = true;

end
% =========================================================================
% build_grid
% =========================================================================
%
% CONSTRUCCIÓN DE LA MALLA ESPACIO-TEMPORAL
% ECUACIÓN DE CALOR 1D
%
% =========================================================================


%% ========================================================================
% 1. VALIDACIÓN DE PARÁMETROS
% ========================================================================

if ~(isnumeric(L) && isscalar(L) && L > 0)

    error('L debe ser un escalar positivo.')

end


if ~(isnumeric(T) && isscalar(T) && T > 0)

    error('T debe ser un escalar positivo.')

end


if ~(isnumeric(dx) && isscalar(dx) && dx > 0)

    error('dx debe ser un escalar positivo.')

end


if ~(isnumeric(dt) && isscalar(dt) && dt > 0)

    error('dt debe ser un escalar positivo.')

end

%
% La discretización espacial utiliza Nx nodos
% uniformemente distribuidos en:
%
%     [0,L]
%
% incluyendo las fronteras.
%
% La discretización temporal contiene Nt instantes
% en:
%
%     [0,T]
%
%% ========================================================================
% 2. CONSTRUCCIÓN DE LA MALLA ESPACIAL
% ========================================================================
%
% Se fuerza que:
%
% x(end)=L
%
% para evitar errores de redondeo.
%
% ========================================================================

Nx = round(L/dx) + 1;
if Nx < 3

    error('La malla espacial debe contener al menos 3 nodos.')

end
x = linspace(0,L,Nx);


%% ========================================================================
% 3. REAJUSTE DE dx
% ========================================================================

dx_real = x(2)-x(1);
if abs(dx_real - dx) > 1e-12

    warning(['dx fue reajustado automaticamente ', ...
             'para ajustar exactamente el dominio.'])

end

%% ========================================================================
% 4. CONSTRUCCIÓN DE LA MALLA TEMPORAL
% ========================================================================

Nt = round(T/dt) + 1;
if Nt < 2

    error('La malla temporal debe contener al menos 2 instantes.')

end
t = linspace(0,T,Nt);


%% ========================================================================
% 5. REAJUSTE DE dt
% ========================================================================

dt_real = t(2)-t(1);

if abs(dt_real - dt) > 1e-12

    warning(['dt fue reajustado automaticamente ', ...
             'para ajustar exactamente el intervalo temporal.'])

end
%% ========================================================================
% 6. PARÁMETRO ADIMENSIONAL dt/dx²
% ========================================================================

difussion_ratio = dt_real/(dx_real^2);


%% ========================================================================
% 7. NODOS INTERIORES
% ========================================================================

inner_idx = 2:(Nx-1);


%% ========================================================================
% 8. EMPAQUETADO DE LA ESTRUCTURA
% ========================================================================

grid.x = x(:);

grid.t = t(:);

grid.Nx = Nx;

grid.Nt = Nt;

grid.inner_idx = inner_idx;

grid.dx = dx_real;

grid.dt = dt_real;

grid.difussion_ratio = difussion_ratio;
%% ========================================================================
% 9. INFORMACIÓN COMPUTACIONAL
% ========================================================================
if verbose
fprintf('\n')

fprintf('====================================\n')

fprintf('MALLA ESPACIO-TEMPORAL\n')

fprintf('====================================\n')

fprintf('Nx = %d\n',Nx)

fprintf('Nt = %d\n',Nt)

fprintf('dx = %.6e\n',dx_real)

fprintf('dt = %.6e\n',dt_real)

fprintf('dt/dx^2 = %.6f\n',difussion_ratio)

fprintf('====================================\n')

end
%% ========================================================================
% 10. VALIDACIONES FINALES
% ========================================================================

if length(inner_idx) ~= Nx-2

    error('Error interno en nodos interiores.')

end


if any(diff(x)<=0)

    error('La malla espacial no es creciente.')

end


if any(diff(t)<=0)

    error('La malla temporal no es creciente.')

end


end