function postprocess_plot( ...
            mesh,...
            detU,...
            stats,...
            sigma,...
            alpha,...
            savefigs,...
            fname_prefix)

% =========================================================================
% POSTPROCESS_PLOT
% =========================================================================
%
% VISUALIZACIÓN CIENTÍFICA DEL MODELO DE CALOR
%
% FIGURAS GENERADAS:
%
% 1. Comparación determinista vs estocástico
% 2. Bandas de incertidumbre
% 3. Error absoluto espacial
% 4. Error relativo espacial
% 5. RMSE temporal
% 6. Energía temporal
% 7. Heatmap promedio
% 8. Heatmap de incertidumbre
% 9. Heatmap del error
% 10. Heatmap coeficiente de variación
%
% =========================================================================


%% ========================================================================
% VALIDACIÓN
% ========================================================================

if nargin < 6
    savefigs = false;
end

if nargin < 7 || isempty(fname_prefix)
    fname_prefix = 'heat_sim';
end


%% ========================================================================
% VARIABLES
% ========================================================================

x = mesh.x(:);

t = mesh.t(:);

T = t(end);


%% ========================================================================
% SOLUCIÓN FINAL
% ========================================================================

det_final  = detU(:,end);

mean_final = stats.mean(:,end);

var_final  = stats.var(:,end);

std_final  = sqrt(var_final);


upper_final = mean_final + 2*std_final;

lower_final = mean_final - 2*std_final;


%% ========================================================================
% ERRORES
% ========================================================================

abs_error = abs(mean_final - det_final);

rel_error = abs_error ./ (abs(det_final) + 1e-8);

error_map = abs(stats.mean - detU);


%% ========================================================================
% LIMITAR CV EXTREMO
% ========================================================================

cv_plot = stats.cv;

cv_plot(cv_plot > 10) = 10;


%% ========================================================================
% RMSE TEMPORAL
% ========================================================================

rmse_t = sqrt( ...
            mean( ...
            (stats.mean - detU).^2 , ...
            1 ) );


%% ========================================================================
% ENERGÍA TEMPORAL
% ========================================================================

energy_t = sum(stats.mean.^2,1)*mesh.dx;


%% ========================================================================
% CONFIGURACIÓN GRÁFICA
% ========================================================================

lw = 2;

fs = 12;

figHandles = [];


%% ========================================================================
% 1. COMPARACIÓN FINAL
% ========================================================================

f1 = figure('Name','Comparacion_Final');

plot(x,det_final,'k-','LineWidth',lw)

hold on

plot(x,mean_final,'r--','LineWidth',lw)

grid on

xlabel('x','FontSize',fs)

ylabel('Temperatura','FontSize',fs)

title(sprintf( ...
'Perfil térmico final (\\sigma = %.3f)',...
sigma),'FontSize',13)

legend( ...
    'Determinista',...
    'Media estocástica',...
    'Location','best')

set(gca,'FontSize',11)

box on

figHandles(end+1)=f1;


%% ========================================================================
% 2. BANDAS DE INCERTIDUMBRE
% ========================================================================

f2 = figure('Name','Bandas_Incertidumbre');

fill( ...
    [x ; flipud(x)],...
    [upper_final ; flipud(lower_final)],...
    [0.85 0.85 0.85],...
    'EdgeColor','none')

hold on

plot(x,mean_final,'b-','LineWidth',lw)

plot(x,det_final,'k--','LineWidth',1.5)

grid on

xlabel('x','FontSize',fs)

ylabel('Temperatura','FontSize',fs)

title(sprintf( ...
'Bandas de incertidumbre (\\sigma = %.3f)',...
sigma),'FontSize',13)

legend( ...
    '95% confianza',...
    'Media estocástica',...
    'Determinista',...
    'Location','best')

set(gca,'FontSize',11)

box on

figHandles(end+1)=f2;


%% ========================================================================
% 3. ERROR ABSOLUTO
% ========================================================================

f3 = figure('Name','Error_Absoluto');

plot(x,abs_error,'m-','LineWidth',lw)

grid on

xlabel('x','FontSize',fs)

ylabel('|u_{MC} - u_{det}|','FontSize',fs)

title('Error absoluto espacial final','FontSize',13)

set(gca,'FontSize',11)

box on

figHandles(end+1)=f3;


%% ========================================================================
% 4. ERROR RELATIVO
% ========================================================================

f4 = figure('Name','Error_Relativo');

plot(x,rel_error,'g-','LineWidth',lw)

grid on

xlabel('x','FontSize',fs)

ylabel('Error relativo','FontSize',fs)

title('Error relativo espacial','FontSize',13)

set(gca,'FontSize',11)

box on

figHandles(end+1)=f4;


%% ========================================================================
% 5. RMSE TEMPORAL
% ========================================================================

f5 = figure('Name','RMSE_Temporal');

plot(t,rmse_t,'b-','LineWidth',lw)

grid on

xlabel('t','FontSize',fs)

ylabel('RMSE','FontSize',fs)

title('Evolución temporal del RMSE','FontSize',13)

set(gca,'FontSize',11)

box on

figHandles(end+1)=f5;


%% ========================================================================
% 6. ENERGÍA TEMPORAL
% ========================================================================

f6 = figure('Name','Energia_Temporal');

plot(t,energy_t,'r-','LineWidth',lw)

grid on

xlabel('t','FontSize',fs)

ylabel('Energía térmica','FontSize',fs)

title('Evolución temporal de energía','FontSize',13)

set(gca,'FontSize',11)

box on

figHandles(end+1)=f6;


%% ========================================================================
% 7. HEATMAP PROMEDIO
% ========================================================================

f7 = figure('Name','Heatmap_Promedio');

imagesc(t,x,stats.mean)

axis xy

colorbar

colormap(turbo)

xlabel('t','FontSize',fs)

ylabel('x','FontSize',fs)

title('Mapa térmico promedio','FontSize',13)

set(gca,'FontSize',11)

figHandles(end+1)=f7;


%% ========================================================================
% 8. HEATMAP VARIANZA
% ========================================================================

f8 = figure('Name','Heatmap_Varianza');

imagesc(t,x,stats.var)

axis xy

colorbar

colormap(parula)

xlabel('t','FontSize',fs)

ylabel('x','FontSize',fs)

title('Mapa de incertidumbre','FontSize',13)

set(gca,'FontSize',11)

figHandles(end+1)=f8;


%% ========================================================================
% 9. HEATMAP ERROR
% ========================================================================

f9 = figure('Name','Heatmap_Error');

imagesc(t,x,error_map)

axis xy

colorbar

colormap(hot)

xlabel('t','FontSize',fs)

ylabel('x','FontSize',fs)

title('Mapa del error absoluto','FontSize',13)

set(gca,'FontSize',11)

figHandles(end+1)=f9;


%% ========================================================================
% 10. HEATMAP CV
% ========================================================================

f10 = figure('Name','Heatmap_CV');

imagesc(t,x,cv_plot)

axis xy

colorbar

colormap(jet)

caxis('auto')

xlabel('t','FontSize',fs)

ylabel('x','FontSize',fs)

title('Coeficiente de variación espacial','FontSize',13)

set(gca,'FontSize',11)

figHandles(end+1)=f10;


%% ========================================================================
% 11. EXPORTACIÓN ROBUSTA
% ========================================================================

if savefigs

    for k = 1:length(figHandles)

        try

            if isgraphics(figHandles(k))

                exportgraphics( ...
                    figHandles(k),...
                    sprintf('%s_fig_%02d.png', ...
                    fname_prefix,k),...
                    'Resolution',300);

            end

        catch ME

            warning('Error exportando figura %d: %s', ...
                    k,ME.message)

        end

    end

    fprintf('Figuras exportadas correctamente\n')

end


%% ========================================================================
% 12. RESUMEN NUMÉRICO
% ========================================================================

fprintf('\n')

fprintf('====================================\n')

fprintf('RESUMEN DE RESULTADOS\n')

fprintf('====================================\n')

fprintf('Tiempo final = %.3f\n', T)

fprintf('alpha = %.5e\n', alpha)

fprintf('sigma = %.3f\n', sigma)

fprintf('\n')

fprintf('RMSE final = %.6e\n', rmse_t(end))

fprintf('RMSE promedio = %.6e\n', mean(rmse_t))

fprintf('\n')

fprintf('Varianza máxima = %.6e\n', ...
        max(stats.var(:)))

fprintf('Varianza media = %.6e\n', ...
        mean(stats.var(:)))

fprintf('Desviación estándar máxima = %.6e\n', ...
        max(std_final(:)))

fprintf('CV máximo = %.6e\n', ...
        max(cv_plot(:)))

fprintf('Energía final = %.6e\n', ...
        energy_t(end))

fprintf('\n')

fprintf('====================================\n\n')

end