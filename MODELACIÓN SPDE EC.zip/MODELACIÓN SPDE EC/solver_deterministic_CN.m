function [U_all,U_metrics] = solver_deterministic_CN( ...
                    U0,...
                    Ah,...
                    grid,...
                    verbose)
%% ========================================================================
% 0. OPCIÓN DE IMPRESIÓN
% ========================================================================

if nargin < 4 || isempty(verbose)

    verbose = true;

end
if ~(islogical(verbose) || isnumeric(verbose))

    error('verbose debe ser logical o numerico.')

end

verbose = logical(verbose);
% =========================================================================
% solver_deterministic_CN
% =========================================================================
%
% ECUACIÓN DE CALOR 1D
%
%     du/dt = alpha * u_xx
%
% Método:
%
%     Crank–Nicolson
%
% Esquema:
%
% (I - dt/2 A_h) U^(n+1)
% =
% (I + dt/2 A_h) U^n
%
% =========================================================================
%
% MEJORAS INCORPORADAS
%
% ✓ Validaciones robustas
% ✓ Factorización LU estable
% ✓ Monitoreo energético
% ✓ Control de NaN/Inf
% ✓ Compatibilidad vectorial
% ✓ Exportación científica consistente
%
% =========================================================================



%% ========================================================================
% 1. VALIDACIONES
% ========================================================================
required_fields = { ...
    'Nx','Nt','dx','dt', ...
    'inner_idx','x','t'};

for i = 1:length(required_fields)

    if ~isfield(grid,required_fields{i})

        error(['Falta grid.',required_fields{i}])

    end

end
Nx    = grid.Nx;

Nt    = grid.Nt;

dt    = grid.dt;

dx    = grid.dx;

inner = grid.inner_idx;
m = Nx - 2;
if size(Ah,1) ~= m || size(Ah,2) ~= m

    error( ...
    'Dimensión incompatible entre Ah y grid.Nx')

end
if isempty(Ah)

    error('Ah no puede ser vacia.')

end

if any(~isfinite(nonzeros(Ah)))

    error('Ah contiene NaN o Inf.')

end

if length(U0) ~= Nx

    error( ...
    'La condición inicial U0 tiene dimensión incorrecta')

end
if ~(isnumeric(U0) && isvector(U0))

    error('U0 debe ser un vector numérico.')

end


if any(~isfinite(U0(:)))

    error('U0 contiene NaN o Inf.')

end

if dt <= 0

    error('dt debe ser positivo')

end


if dx <= 0

    error('dx debe ser positivo')

end



%% ========================================================================
% 2. RELACIÓN TEMPORAL-ESPACIAL
% ========================================================================
%
% Aunque Crank–Nicolson es incondicionalmente estable
% para la ecuación de calor lineal, el cociente:
%
%       dt/dx^2
%
% sigue siendo relevante para la precisión numérica.
%
% Valores elevados pueden introducir:
%
% - difusión numérica
% - pérdida de resolución temporal
% - amortiguamiento excesivo
%
% ========================================================================
cfl = dt/(dx^2);

if verbose

    fprintf('\n')

    fprintf('--------------------------------------------\n')

    fprintf('Relacion temporal-espacial\n')
    fprintf('dt/dx^2 = %.4e\n',cfl)

    fprintf('--------------------------------------------\n')

end


if verbose && cfl > 1

    fprintf('\n')
    fprintf('Aviso: dt/dx^2 = %.4f\n',cfl)
    fprintf('La estabilidad no se ve afectada,\n')
    fprintf('pero la precisión temporal puede degradarse.\n')

end


%% ========================================================================
% 3. MATRICES CRANK-NICOLSON
% ========================================================================
% Discretización Crank–Nicolson:
%
%     U^(n+1) - U^n
%     ----------------
%            dt
%
% = 1/2 A_h(U^(n+1)+U^n)
%
I = speye(m);


A_lhs = I - 0.5*dt*Ah;

A_rhs = I + 0.5*dt*Ah;


%% ========================================================================
% 4. FACTORIZACIÓN LU ESTABLE
% ========================================================================

[Lfac,Ufac,Pfac] = lu(A_lhs);
if any(~isfinite(nonzeros(Lfac))) || ...
   any(~isfinite(nonzeros(Ufac)))

    error('La factorizacion LU produjo NaN o Inf.')

end
% La matriz implícita permanece constante
% durante toda la simulación, por lo que
% la factorización LU se realiza una sola vez.

%% ========================================================================
% 5. PREALOCACIÓN
% ========================================================================

U_all = zeros(Nx,Nt);


U_all(:,1) = U0(:);


U_int = U0(inner);

U_int = U_int(:);


%% ========================================================================
% 6. MONITOREO ENERGÉTICO
% ========================================================================

energy = zeros(1,Nt);

energy(1) = sum(U_int.^2)*dx;


max_temp = zeros(1,Nt);

max_temp(1) = max(abs(U_int));

%% ========================================================================
% 7. INTERPRETACIÓN DEL ESQUEMA
% ========================================================================
%
% Crank–Nicolson combina:
%
% - estabilidad implícita
% - precisión temporal de segundo orden
%
% para aproximar la dinámica difusiva
% preservando adecuadamente el decaimiento energético.
%
% ========================================================================
%% ========================================================================
% 8. BUCLE TEMPORAL
% ========================================================================

for n = 1:Nt-1


    %% --------------------------------------------------------------------
    % RHS
    % ---------------------------------------------------------------------

    b = A_rhs * U_int;

    b = b(:);


    %% --------------------------------------------------------------------
    % SOLUCIÓN DEL SISTEMA
    % ---------------------------------------------------------------------

    y = Lfac\(Pfac*b);

    U_int = Ufac\y;

    U_int = U_int(:);


    %% --------------------------------------------------------------------
    % VALIDACIÓN DE ESTABILIDAD NUMÉRICA
    % ---------------------------------------------------------------------

    if any(~isfinite(U_int))

        error('Valores no finitos detectados en solución determinista')

    end


    %% --------------------------------------------------------------------
    % ALMACENAMIENTO
    % ---------------------------------------------------------------------

    U_all(inner,n+1) = U_int;


    %% --------------------------------------------------------------------
    % MÉTRICAS
    % ---------------------------------------------------------------------
    % Aproximación discreta de:
    %
    %   ||u||^2_{L2}
    %
    % que representa la energía térmica del sistema.
    energy(n+1) = sum(U_int.^2)*dx;

    max_temp(n+1) = max(abs(U_int));
% Monitoreo de amplitud máxima
% para detectar posibles anomalías numéricas.

end


%% ========================================================================
% 8. CONDICIONES DE BORDE
% ========================================================================

U_all(1,:) = 0;

U_all(end,:) = 0;


%% ========================================================================
% 9. VALIDACIÓN FINAL
% ========================================================================

if any(isnan(U_all(:)))

    warning(['Valores NaN detectados en la solucion final. ', ...
         'Esto puede indicar perdida de estabilidad numerica.'])

end


if any(isinf(U_all(:)))

    warning(['Valores Inf detectados en la solucion final. ', ...
         'Esto puede indicar inestabilidad numerica.'])

end

%% ========================================================================
% VERIFICACIÓN ENERGÉTICA
% ========================================================================
%
% Para la ecuación de calor determinista,
% la energía debe decrecer monótonamente
% debido al carácter disipativo del operador
% difusivo.
%
% ========================================================================
energy_decay = energy(end)/energy(1);
energy_growth = max(diff(energy));
if abs(energy_decay) < 1e-12
    energy_decay = 0;
end

if energy_growth > 1e-8

    warning(['La energia presenta crecimiento numerico ', ...
             'apreciable. Revisar discretizacion temporal.'])

end
if verbose

    fprintf('Razón energía final/inicial = %.6e\n', ...
        energy_decay)

end
%% ========================================================================
% 10. REPORTE NUMÉRICO
% ========================================================================
if verbose
fprintf('\n')

fprintf('====================================\n')

fprintf('RESUMEN DETERMINISTA CN\n')

fprintf('====================================\n')

fprintf('Temperatura máxima = %.6e\n', ...
        max(U_all(:)))

fprintf('Temperatura mínima = %.6e\n', ...
        min(U_all(:)))

fprintf('Energía final = %.6e\n', ...
        energy(end))

fprintf('Máxima energía = %.6e\n', ...
        max(energy))

fprintf('====================================\n')

end
%
% Métricas adicionales
%

U_metrics.energy = energy;

U_metrics.max_temp = max_temp;
U_metrics.energy_decay = energy_decay;
U_metrics.final_solution = U_all(:,end);
end