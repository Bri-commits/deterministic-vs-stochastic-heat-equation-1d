function Ah = assemble_Ah(Nx,dx,alpha,verbose)
%% ========================================================================
% 0. OPCIÓN DE IMPRESIÓN
% ========================================================================

if nargin < 4

    verbose = true;

end
% =========================================================================
% assemble_Ah
% =========================================================================
%
% OPERADOR LAPLACIANO DISCRETO 1D
%
% Aproxima:
%
%     alpha * d²u/dx²
%
% utilizando diferencias finitas centrales de segundo orden.
%
%
% =========================================================================
% FUNDAMENTO NUMÉRICO
% =========================================================================
%
% Aproximación:
%
% d²u/dx² ≈ (u_{j+1} - 2u_j + u_{j-1}) / dx²
%
%
% Operador discreto:
%
% A_h = (alpha/dx²) * tridiag(1,-2,1)
%
%
% =========================================================================
% MEJORAS INCORPORADAS
% =========================================================================
%
% ✓ Validaciones robustas
% ✓ Compatibilidad dimensional
% ✓ Verificación de estabilidad física
% ✓ Diagnóstico espectral
% ✓ Simetría garantizada
% ✓ Matriz esparsa eficiente
% ✓ Reporte numérico científico
%
% =========================================================================


%% ========================================================================
% 1. VALIDACIONES
% ========================================================================

if nargin < 3

    error( ...
    'assemble_Ah requiere Nx, dx y alpha.')

end

if ~(isnumeric(Nx) && isscalar(Nx) && Nx == floor(Nx))

    error('Nx debe ser un entero.')

end


if ~(isnumeric(dx) && isscalar(dx) && isfinite(dx))

    error('dx debe ser un escalar finito.')

end


if ~(isnumeric(alpha) && isscalar(alpha) && isfinite(alpha))

    error('alpha debe ser un escalar finito.')

end
if Nx < 3

    error( ...
    'Nx debe ser al menos 3')

end


if dx <= 0

    error( ...
    'dx debe ser positivo')

end


if alpha <= 0

    error( ...
    'alpha debe ser positivo')

end


%% ========================================================================
% 2. GRADOS DE LIBERTAD INTERIORES
% ========================================================================

m = Nx - 2;

if m < 1
    error('No existen nodos interiores.');
end
%% ========================================================================
% 3. CONSTRUCCIÓN DEL LAPLACIANO
% ========================================================================

e = ones(m,1);


L = spdiags( ...
        [e -2*e e], ...
        -1:1, ...
        m, ...
        m);
% La estructura tridiagonal dispersa permite:
%
% - reducir memoria
% - acelerar factorizaciones
% - mejorar escalabilidad numérica
%
% especialmente para discretizaciones finas.

%% ========================================================================
% 4. ESCALAMIENTO FÍSICO
% ========================================================================

Ah = (alpha/dx^2)*L;

% El operador discreto resultante es:
%
% - simétrico
% - definido negativo
% - disipativo
%
% propiedades fundamentales para la estabilidad
% de la ecuación de calor.
%% ========================================================================
% 5. VALIDACIÓN DE SIMETRÍA
% ========================================================================

symmetry_error = norm(Ah-Ah',inf);


if symmetry_error > 1e-12

    warning( ...
    'La matriz Ah no es simétrica')

end


%% ========================================================================
% 6. DIAGNÓSTICO ESPECTRAL
% ========================================================================
%
% Para la ecuación de calor,
% el operador difusivo debe ser
% definido negativo.
%
% Esto garantiza:
%
% - disipación energética
% - amortiguamiento de modos
% - estabilidad física del sistema
%
% En particular:
%
%     lambda(A_h) < 0
%
% para todos los autovalores.
%
% ========================================================================

try

    % El autovalor más cercano a cero controla
    % los modos difusivos de baja frecuencia.
    lambda_max = eigs(Ah,1,'lr');

    % El autovalor más negativo corresponde
    % a los modos espaciales más oscilatorios.
    lambda_min = eigs(Ah,1,'sr');

catch

    eigvals = eig(full(Ah));

    lambda_max = max(real(eigvals));

    lambda_min = min(real(eigvals));

end


%% ========================================================================
% 7. VALIDACIÓN FÍSICA
% ========================================================================

if lambda_max > 1e-12

    warning(['El operador discreto posee autovalores positivos. ', ...
         'Esto contradice el carácter disipativo esperado.'])
end
if abs(imag(lambda_max)) > 1e-12 || ...
   abs(imag(lambda_min)) > 1e-12

    warning('Se detectaron autovalores complejos.')

end

lambda_max = real(lambda_max);
lambda_min = real(lambda_min);

%% ========================================================================
% 8. REPORTE NUMÉRICO
% ========================================================================

if verbose

    fprintf('\n')

    fprintf('====================================\n')

    fprintf('OPERADOR DIFUSIVO DISCRETO Ah\n')

    fprintf('====================================\n')

    fprintf('Nodos interiores = %d\n',m)

    fprintf('dx = %.4e\n',dx)

    fprintf('alpha = %.4e\n',alpha)

    fprintf('Norma Frobenius = %.4e\n', ...
            norm(Ah,'fro'))

    fprintf('Error simetría = %.4e\n', ...
            symmetry_error)

    fprintf('Autovalor máximo = %.4e\n', ...
            lambda_max)

    fprintf('Autovalor mínimo = %.4e\n', ...
            lambda_min)

    fprintf('====================================\n')

end

%% ========================================================================
% CONSISTENCIA DEL OPERADOR
% ========================================================================
%
% El operador construido representa una aproximación
% de segundo orden del Laplaciano continuo:
%
%     ||A_h - A|| = O(dx^2)
%
% bajo discretización uniforme.
%
% ========================================================================
%% ========================================================================
% 9. VALIDACIÓN FINAL
% ========================================================================

if any(isnan(nonzeros(Ah)))

    error('NaNs detectados en Ah')

end


if any(isinf(nonzeros(Ah)))

    error('Inf detectados en Ah')

end


end