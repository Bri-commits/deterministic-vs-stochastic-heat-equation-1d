function study_energy_evolution

clc
close all

fprintf('\n')
fprintf('====================================\n')
fprintf('EVOLUCION DE LA ENERGIA\n')
fprintf('====================================\n')

%% ------------------------------------------------------------
% Parametros
% -------------------------------------------------------------

L = 1;
T = 0.5;

alpha = 1;

dx = 0.01;
dt = 1e-4;

Nmc = 1000;

sigma_values = [ ...
    0.10 ...
    0.20 ...
    0.50 ...
    1.00 ];

%% ------------------------------------------------------------
% Malla
% -------------------------------------------------------------

mesh = build_grid(L,T,dx,dt);

%% ------------------------------------------------------------
% Operador
% -------------------------------------------------------------

Ah = assemble_Ah( ...
        mesh.Nx,...
        mesh.dx,...
        alpha);

%% ------------------------------------------------------------
% Condicion inicial
% -------------------------------------------------------------

x = mesh.x;

U0 = sin(pi*x);

%% ------------------------------------------------------------
% Solucion determinista
% -------------------------------------------------------------

detU = solver_deterministic_CN( ...
            U0,...
            Ah,...
            mesh);

%% ------------------------------------------------------------
% Energia determinista
% -------------------------------------------------------------

EnergyDet = zeros(mesh.Nt,1);

for n = 1:mesh.Nt

    EnergyDet(n) = ...
        sum(detU(:,n).^2)*mesh.dx;

end

%% ------------------------------------------------------------
% Figura
% -------------------------------------------------------------

figure

plot( ...
    mesh.t,...
    EnergyDet,...
    'k',...
    'LineWidth',3)

hold on

%% ------------------------------------------------------------
% Monte Carlo
% -------------------------------------------------------------

opts.rngSeed = 1;

for k = 1:length(sigma_values)

    sigma = sigma_values(k);

    fprintf('\n')
    fprintf('sigma = %.2f\n',sigma)

    stats = montecarlo_runner( ...
            U0,...
            Ah,...
            mesh,...
            sigma,...
            Nmc,...
            opts);

    EnergyMean = zeros(mesh.Nt,1);

    for n = 1:mesh.Nt

        EnergyMean(n) = ...
            sum(stats.mean(:,n).^2)*mesh.dx;

    end

    plot( ...
        mesh.t,...
        EnergyMean,...
        'LineWidth',2)

end

%% ------------------------------------------------------------
% Grafica
% -------------------------------------------------------------

grid on

xlabel('t')

ylabel('Energia')

title('Evolucion temporal de la energia')

legend( ...
'Determinista',...
'\sigma=0.10',...
'\sigma=0.20',...
'\sigma=0.50',...
'\sigma=1.00',...
'Location','best')

end