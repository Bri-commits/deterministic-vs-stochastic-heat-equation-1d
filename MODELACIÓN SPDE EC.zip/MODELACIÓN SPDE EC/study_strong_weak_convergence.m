% =========================================================================
% study_strong_weak_convergence.m
% =========================================================================
%
% ESTUDIO DE CONVERGENCIA FUERTE Y DÉBIL
%
% Ecuación:
%
%      du = alpha*u_xx dt + sigma dW
%
% Método:
%
%      Euler-Maruyama implícito
%
% Objetivo:
%
% Verificar experimentalmente:
%
%   Error fuerte ~ O(dt^(1/2))
%
%   Error débil  ~ O(dt)
%
% =========================================================================

clear
close all
clc

fprintf('\n')
fprintf('====================================\n')
fprintf('CONVERGENCIA FUERTE Y DEBIL\n')
fprintf('====================================\n')

%% ========================================================================
% PARÁMETROS
% ========================================================================

L = 1;

T = 0.5;

alpha = 1;

sigma = 0.20;

dx = 0.01;

Nmc = 500;

dt_ref = 5e-5;

dt_values = [ ...
    2e-4 ...
    5e-4 ...
    1e-3 ...
    2e-3 ];

%% ========================================================================
% MALLA DE REFERENCIA
% ========================================================================

mesh_ref = build_grid( ...
                L,...
                T,...
                dx,...
                dt_ref);

Ah_ref = assemble_Ah( ...
            mesh_ref.Nx,...
            mesh_ref.dx,...
            alpha);

U0 = sin(pi*mesh_ref.x);

m = mesh_ref.Nx - 2;

Nt_ref = mesh_ref.Nt;

%% ========================================================================
% VECTORES DE ERROR
% ========================================================================

StrongError = zeros(length(dt_values),1);

WeakError = zeros(length(dt_values),1);

%% ========================================================================
% BUCLE SOBRE dt
% ========================================================================

for idt = 1:length(dt_values)

    dt = dt_values(idt);

    fprintf('\n')
    fprintf('Caso %d de %d\n',idt,length(dt_values))
    fprintf('dt = %.6e\n',dt)

    mesh = build_grid( ...
                L,...
                T,...
                dx,...
                dt);

    Ah = assemble_Ah( ...
            mesh.Nx,...
            mesh.dx,...
            alpha);

    ratio = round(dt/dt_ref);
    if abs(ratio*dt_ref - dt) > 1e-12
    
        error('dt debe ser múltiplo entero de dt_ref.')
    
    end
    strong_acc = 0;

    weak_ref_acc = zeros(mesh_ref.Nx,1);

    weak_num_acc = zeros(mesh.Nx,1);

    %% ------------------------------------------------------------
    % MONTE CARLO
    % -------------------------------------------------------------

    for k = 1:Nmc

        %% --------------------------------------------------------
        % Trayectoria browniana fina
        % ---------------------------------------------------------

        dW_ref = sqrt(dt_ref) * randn(m,Nt_ref-1);

        %% --------------------------------------------------------
        % Solución referencia
        % ---------------------------------------------------------

        [Uref,~] = solver_stochastic_EM( ...
                    U0,...
                    Ah_ref,...
                    mesh_ref,...
                    sigma,...
                    [],...
                    dW_ref);

        %% --------------------------------------------------------
        % Construcción del ruido grueso
        % ---------------------------------------------------------

        dW_coarse = zeros(m,mesh.Nt-1);

        for n = 1:mesh.Nt-1

            i1 = (n-1)*ratio + 1;

            i2 = n*ratio;

            dW_coarse(:,n) = ...
                sum(dW_ref(:,i1:i2),2);

        end

        %% --------------------------------------------------------
        % Solución gruesa
        % ---------------------------------------------------------

       [Unum,~] = solver_stochastic_EM( ...
                    U0,...
                    Ah,...
                    mesh,...
                    sigma,...
                    [],...
                    dW_coarse);

        %% --------------------------------------------------------
        % ERROR FUERTE
        % ---------------------------------------------------------

        e = Unum(:,end) - Uref(:,end);

        strong_acc = strong_acc + ...
        mesh.dx*sum(e.^2);

        %% --------------------------------------------------------
        % ERROR DÉBIL
        % ---------------------------------------------------------

        weak_ref_acc = weak_ref_acc + Uref(:,end);

        weak_num_acc = weak_num_acc + Unum(:,end);

    end

    %% ------------------------------------------------------------
    % PROMEDIOS
    % -------------------------------------------------------------

    StrongError(idt) = sqrt(strong_acc/Nmc);

    MeanRef = weak_ref_acc / Nmc;

    MeanNum = weak_num_acc / Nmc;

    WeakError(idt) = ...
        sqrt(mesh.dx * sum((MeanNum-MeanRef).^2));

end

%% ========================================================================
% PENDIENTES
% ========================================================================
if any(StrongError <= 0)

    error('StrongError contiene valores no positivos.')

end

if any(WeakError <= 0)

    error('WeakError contiene valores no positivos.')

end
pStrong = polyfit( ...
            log(dt_values),...
            log(StrongError'),...
            1);

pWeak = polyfit( ...
            log(dt_values),...
            log(WeakError'),...
            1);
fprintf('\n')
fprintf('Error pendiente fuerte = %.4f\n', ...
        abs(pStrong(1)-0.5));

fprintf('Error pendiente débil  = %.4f\n', ...
        abs(pWeak(1)-1.0));
%% ========================================================================
% TABLA
% ========================================================================

fprintf('\n')

fprintf('========================================================\n')
fprintf(' dt         Strong Error      Weak Error\n')
fprintf('========================================================\n')

for k=1:length(dt_values)

    fprintf('%.4e   %.6e   %.6e\n', ...
        dt_values(k), ...
        StrongError(k), ...
        WeakError(k));

end

fprintf('========================================================\n')

fprintf('\n')
fprintf('Pendiente fuerte = %.4f\n',pStrong(1))
fprintf('Teoría           = 0.5000\n')

fprintf('\n')
fprintf('Pendiente débil  = %.4f\n',pWeak(1))
fprintf('Teoría           = 1.0000\n')

%% ========================================================================
% FIGURA
% ========================================================================

figure

loglog( ...
    dt_values,...
    StrongError,...
    '-o',...
    'LineWidth',2)

hold on

loglog( ...
    dt_values,...
    WeakError,...
    '-s',...
    'LineWidth',2)

grid on

xlabel('\Deltat')

ylabel('Error')

title('Convergencia fuerte y débil')

legend( ...
    'Error fuerte',...
    'Error débil',...
    'Location','best')