clear
close all
clc

fprintf('\n')
fprintf('====================================\n')
fprintf('CONVERGENCIA MONTE CARLO\n')
fprintf('====================================\n')


%% ============================================================
% PARÁMETROS
% =============================================================

L = 1;

T = 0.5;

alpha = 1;

dx = 0.01;

dt = 1e-4;

sigma = 0.2;


%% ============================================================
% NÚMERO DE REALIZACIONES
% =============================================================

Nmc_values = [10 20 50 100 200 500 1000];

nCases = length(Nmc_values);


%% ============================================================
% MALLA
% =============================================================

grid = build_grid(L,T,dx,dt);


%% ============================================================
% CONDICIÓN INICIAL
% =============================================================

U0 = sin(pi*grid.x);


%% ============================================================
% OPERADOR
% =============================================================

Ah = assemble_Ah( ...
        grid.Nx,...
        grid.dx,...
        alpha);


%% ============================================================
% SOLUCIÓN DETERMINISTA
% =============================================================

detU = solver_deterministic_CN( ...
            U0,...
            Ah,...
            grid);


%% ============================================================
% VECTOR DE ERRORES
% =============================================================

errorsL2 = zeros(nCases,1);


%% ============================================================
% OPCIONES MONTE CARLO
% =============================================================

opts.store_all = false;

opts.parallel = false;


%% ============================================================
% BUCLE PRINCIPAL
% =============================================================

for k = 1:nCases

    Nmc = Nmc_values(k);

    opts.rngSeed = 1;

    fprintf('\n')
    fprintf('Caso %d de %d\n',k,nCases)
    fprintf('Nmc = %d\n',Nmc)

    stats = montecarlo_runner( ...
                U0,...
                Ah,...
                grid,...
                sigma,...
                Nmc,...
                opts);

    errorL2 = norm( ...
              stats.mean(:,end) ...
            - detU(:,end),2);

    errorsL2(k) = errorL2;

    fprintf('Error L2 = %.6e\n',errorL2)

end


%% ============================================================
% TABLA
% =============================================================

fprintf('\n')

fprintf('====================================\n')
fprintf('RESULTADOS\n')
fprintf('====================================\n')

fprintf(' Nmc         Error L2\n')
fprintf('-----------------------------\n')

for k = 1:nCases

    fprintf('%6d    %12.6e\n', ...
            Nmc_values(k), ...
            errorsL2(k));

end

fprintf('====================================\n')


%% ============================================================
% PENDIENTE LOG-LOG
% =============================================================

p = polyfit( ...
        log(Nmc_values), ...
        log(errorsL2'), ...
        1);

slope = p(1);

fprintf('\n')

fprintf('Pendiente log-log = %.6f\n',slope)

fprintf('Pendiente teórica = -0.500000\n')


%% ============================================================
% GRÁFICA
% =============================================================

figure

loglog( ...
    Nmc_values,...
    errorsL2,...
    'o-',...
    'LineWidth',2,...
    'MarkerSize',8)

grid on

xlabel('N_{MC}')

ylabel('Error L2')

title('Convergencia Monte Carlo')

set(gca,'FontSize',12)


%% ============================================================
% RECTA TEÓRICA
% =============================================================

hold on

ref = errorsL2(1) * ...
      (Nmc_values/Nmc_values(1)).^(-0.5);

loglog( ...
    Nmc_values,...
    ref,...
    '--',...
    'LineWidth',2)

legend( ...
    'Experimental',...
    'Orden -1/2', ...
    'Location','southwest')