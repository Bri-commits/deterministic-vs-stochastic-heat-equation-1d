function [U_all,U_metrics] = solver_stochastic_EM( ...
            U0,...
            Ah,...
            grid,...
            sigma,...
            rngSeed,...
            dW_external,...
            noise_type)
% =========================================================================
% solver_stochastic_EM
% =========================================================================
%
% ECUACIÓN DE CALOR ESTOCÁSTICA 1D
%
%     Aditivo:        du = alpha*u_xx dt + sigma dW
%     Multiplicativo: du = alpha*u_xx dt + sigma*u dW
%
% donde dW representa incrementos gaussianos independientes.
%
% =========================================================================
%
% ENTRADAS:
% U0          : condición inicial
% Ah          : operador espacial
% grid        : estructura de la malla
% sigma       : intensidad del ruido
% rngSeed     : semilla para reproducibilidad (opcional)
% dW_external : incrementos de Wiener prescritos (opcional)
% noise_type  : 'additive' (defecto) o 'multiplicative' (opcional)
%
% =========================================================================

%% ========================================================================
% 1. REPRODUCIBILIDAD Y CONFIGURACIÓN DE RUIDO
% ========================================================================
if nargin < 5
    rngSeed = [];
end
if nargin < 6
    dW_external = [];
end
if nargin < 7
    noise_type = 'additive';
end

% Doble validación para no romper scripts antiguos: 
% Si se define dentro de la estructura grid, se respeta.
if isfield(grid, 'noise_type') && (nargin < 7 || isempty(noise_type))
    noise_type = grid.noise_type;
end

% Bandera booleana para alta eficiencia dentro del bucle temporal
is_multiplicative = strcmpi(noise_type, 'multiplicative');

if ~isempty(rngSeed) && isempty(dW_external)
    rng(rngSeed);
end

%% ========================================================================
% 2. PARÁMETROS DE LA MALLA
% ========================================================================
required_fields = { ...
    'Nx','Nt','dx','dt', ...
    'inner_idx','x','t'};
for i = 1:length(required_fields)
    if ~isfield(grid,required_fields{i})
        error(['Falta grid.',required_fields{i}])
    end
end
Nx    = grid.Nx;
Nt    = grid.Nt;
dt    = grid.dt;
inner = grid.inner_idx;
dx    = grid.dx;
m     = Nx - 2;

if dt <= 0, error('dt debe ser positivo.'), end
if dx <= 0, error('dx debe ser positivo.'), end
if Nt < 2,  error('Nt debe ser al menos 2.'), end
if Nx < 3,  error('Nx debe ser al menos 3.'), end

%% ========================================================================
% VALIDACIÓN DEL RUIDO EXTERNO
% ========================================================================
if ~isempty(dW_external)
    if size(dW_external,1) ~= m
        error('Número incorrecto de nodos en dW_external')
    end
    if size(dW_external,2) ~= Nt-1
        error('Número incorrecto de pasos temporales en dW_external')
    end
    if ~isreal(dW_external)
        error('dW_external debe ser real')
    end
    if any(~isfinite(dW_external(:)))
        error('dW_external contiene NaN o Inf')
    end
end

%% ========================================================================
% 3. VALIDACIONES
% ========================================================================
if ~isreal(Ah), error('Ah debe ser real.'), end
if any(~isfinite(nonzeros(Ah))), error('Ah contiene NaN o Inf.'), end
if ~(isnumeric(sigma) && isscalar(sigma) && isfinite(sigma) && sigma >= 0)
    error('sigma debe ser un escalar finito no negativo')
end
if size(Ah,1) ~= m || size(Ah,2) ~= m
    error('Dimensiones incompatibles entre Ah y grid')
end
if length(inner) ~= m, error('grid.inner_idx inconsistente con Nx.'); end
if ~(isvector(U0) && length(U0) == Nx), error('U0 debe ser un vector de longitud Nx'), end
if any(~isfinite(U0(:))), error('U0 contiene NaN o Inf'), end
if ~isreal(U0), error('U0 debe ser real.'), end
if ~all(inner >= 1) || ~all(inner <= Nx)
    error('grid.inner_idx contiene índices fuera de rango.');
end

%% ========================================================================
% 4. MATRIZ IMPLÍCITA
% ========================================================================
I = speye(m);
A_lhs = I - dt*Ah;

%% ========================================================================
% 5. FACTORIZACIÓN LU
% ========================================================================
[Lfac,Ufac,Pfac] = lu(A_lhs);
if any(~isfinite(nonzeros(Lfac))) || any(~isfinite(nonzeros(Ufac)))
    error('La factorizacion LU produjo NaN o Inf.')
end

%% ========================================================================
% 6. PREALOCACIÓN
% ========================================================================
U_all = zeros(Nx,Nt);
U_all(:,1) = U0(:);

%% ========================================================================
% 7. CONDICIÓN INICIAL INTERIOR
% ========================================================================
U_int = U0(inner);
U_int = U_int(:);

%% ========================================================================
% 8. MÉTRICAS
% ========================================================================
energy = zeros(1,Nt);
max_temp = zeros(1,Nt);
energy(1) =  sum(U_int.^2)*dx;
max_temp(1) = max(abs(U_int));

%% ========================================================================
% 9. BUCLE TEMPORAL
% ========================================================================
for n = 1:Nt-1
    %% --------------------------------------------------------------------
    % 9.1 INCREMENTO DEL PROCESO DE WIENER
    % --------------------------------------------------------------------
    if isempty(dW_external)
        eta = randn(m,1);
        dW = sqrt(dt)*eta;
    else
        dW = dW_external(:,n);
    end
    
    %% --------------------------------------------------------------------
    % 9.2 TÉRMINO ESTOCÁSTICO (Adaptado para Ruido Aditivo / Multiplicativo)
    % --------------------------------------------------------------------
    if is_multiplicative
        % El ruido se escala punto a punto según la temperatura actual del nodo
        stochastic_term = sigma * U_int .* dW;
    else
        % Ruido aditivo clásico independiente del estado
        stochastic_term = sigma * dW;
    end
    
    %% --------------------------------------------------------------------
    % 9.3 LADO DERECHO
    % --------------------------------------------------------------------
    b = U_int + stochastic_term;
    b = b(:);
    
    %% --------------------------------------------------------------------
    % 9.4 RESOLVER SISTEMA
    % --------------------------------------------------------------------
    y = Lfac \ (Pfac*b);
    U_new = Ufac \ y;
    U_new = U_new(:);
    
    if any(~isfinite(U_new))
        error('Inestabilidad numérica detectada en solver_stochastic_EM');
    end
    
    %% --------------------------------------------------------------------
    % 9.5 ACTUALIZACIÓN
    % --------------------------------------------------------------------
    U_int = U_new;
    
    %% --------------------------------------------------------------------
    % 9.6 ALMACENAMIENTO
    % --------------------------------------------------------------------
    U_all(inner,n+1) = U_int;
    
    %% --------------------------------------------------------------------
    % 9.7 CONDICIONES DE BORDE (Dirichlet Homogéneas)
    % --------------------------------------------------------------------
    U_all(1,n+1)   = 0;
    U_all(end,n+1) = 0;
    
    %% --------------------------------------------------------------------
    % 9.8 MÉTRICAS
    % --------------------------------------------------------------------
    energy(n+1) = sum(U_int.^2)*dx;
    max_temp(n+1) = max(abs(U_int));
end

%% ========================================================================
% 10. VALIDACIÓN FINAL
% ========================================================================
if any(isnan(U_all(:)))
    warning('NaNs detectados en la solución estocástica')
end
if any(isinf(U_all(:)))
    warning('Inf detectados en la solución estocástica')
end

%% ========================================================================
% 11. INFORMACIÓN ADICIONAL
% ========================================================================
U_metrics.energy = energy;
U_metrics.max_temp = max_temp;
U_metrics.final_solution = U_all(:,end);
if energy(1) > eps
    energy_ratio = energy(end)/energy(1);
else
    energy_ratio = NaN;
end
U_metrics.mean_energy = mean(energy);
U_metrics.energy_ratio = energy_ratio;
U_metrics.energy_initial = energy(1);
U_metrics.final_energy = energy(end);
U_metrics.max_amplitude = max(abs(U_all(:)));
U_metrics.final_norm = norm(U_all(:,end),2);
U_metrics.sigma = sigma;
U_metrics.dt    = dt;
U_metrics.dx    = dx;
U_metrics.initial_norm = norm(U0,2);
U_metrics.max_energy = max(energy);
U_metrics.noise_type = noise_type; % Guarda el tipo de ruido analizado

end