function study_confidence_intervals

clc
close all

fprintf('\n')
fprintf('====================================\n')
fprintf('INTERVALOS DE CONFIANZA MONTE CARLO\n')
fprintf('====================================\n')

%% ============================================================
% PARAMETROS
% =============================================================

L = 1;
T = 0.5;

alpha = 1;

dx = 0.01;
dt = 1e-4;

sigma = 0.20;

Nmc_values = [ ...
    10 ...
    50 ...
    100 ...
    500 ...
    1000];

%% ============================================================
% MALLA
% =============================================================

mesh = build_grid(L,T,dx,dt);

%% ============================================================
% OPERADOR
% =============================================================

Ah = assemble_Ah( ...
        mesh.Nx,...
        mesh.dx,...
        alpha);

%% ============================================================
% CONDICION INICIAL
% =============================================================

x = mesh.x;

U0 = sin(pi*x);

%% ============================================================
% PREALOCACION
% =============================================================

nCases = length(Nmc_values);

ICwidth = zeros(nCases,1);

%% ============================================================
% OPCIONES
% =============================================================

opts.rngSeed = 1;

%% ============================================================
% BUCLE SOBRE NMC
% =============================================================

for k = 1:nCases

    Nmc = Nmc_values(k);

    fprintf('\n')
    fprintf('Nmc = %d\n',Nmc)

    stats = montecarlo_runner( ...
                U0,...
                Ah,...
                mesh,...
                sigma,...
                Nmc,...
                opts);

    %% --------------------------------------------------------
    % IC95%
    % ---------------------------------------------------------

    stderr = stats.std ./ sqrt(Nmc);

    IC_low  = stats.mean - 1.96*stderr;

    IC_high = stats.mean + 1.96*stderr;

    widthIC = mean(IC_high(:)-IC_low(:));

    ICwidth(k) = widthIC;

    fprintf('Ancho medio IC95%% = %.6e\n',widthIC)

end

%% ============================================================
% TABLA RESUMEN
% =============================================================

fprintf('\n')
fprintf('====================================\n')
fprintf('RESULTADOS\n')
fprintf('====================================\n')
fprintf(' Nmc      IC95%% medio\n')
fprintf('-----------------------------\n')

for k = 1:nCases

    fprintf('%5d    %12.6e\n', ...
        Nmc_values(k), ...
        ICwidth(k));

end

fprintf('====================================\n')

%% ============================================================
% FIGURA
% =============================================================

figure

loglog( ...
    Nmc_values,...
    ICwidth,...
    '-o',...
    'LineWidth',2)

grid on

xlabel('N_{MC}')

ylabel('Ancho medio IC95%')

title('Convergencia de los intervalos de confianza')

%% ============================================================
% PENDIENTE EXPERIMENTAL
% =============================================================

p = polyfit( ...
        log(Nmc_values), ...
        log(ICwidth'), ...
        1);

fprintf('\n')
fprintf('====================================\n')
fprintf('CONVERGENCIA DEL IC95%%\n')
fprintf('====================================\n')
fprintf('Pendiente observada = %.6f\n',p(1))
fprintf('Pendiente teorica  = -0.500000\n')

%% ============================================================
% VERIFICACION
% =============================================================

if abs(p(1)+0.5) < 0.1

    fprintf('\n')
    fprintf('====================================\n')
    fprintf('CONVERGENCIA ESTADISTICA VERIFICADA\n')
    fprintf('====================================\n')

else

    fprintf('\n')
    fprintf('====================================\n')
    fprintf('REVISAR NUMERO DE REALIZACIONES\n')
    fprintf('====================================\n')

end

end