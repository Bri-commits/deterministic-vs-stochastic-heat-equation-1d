% =========================================================================
% run_all.m
% =========================================================================
%
% IMPLEMENTACIÓN COMPUTACIONAL COMPLETA
% ECUACIÓN DE CALOR 1D DETERMINISTA Y ESTOCÁSTICA
%
% VERSIÓN CORREGIDA Y ESTABLE
%
% =========================================================================

clearvars
close all
clc


%% ========================================================================
% 0. DEFINICIÓN DE MATERIALES
% ========================================================================

materials = { ...
    'aluminium', ...
    'stainless_steel', ...
    'wood'};


%% ========================================================================
% 0.1 ESTRUCTURA GLOBAL DE RESULTADOS
% ========================================================================

all_materials_results = struct();


%% ========================================================================
% 1. BUCLE PRINCIPAL SOBRE MATERIALES
% ========================================================================

for mat_id = 1:length(materials)

    close all


    %% --------------------------------------------------------------------
    % MATERIAL ACTUAL
    % ---------------------------------------------------------------------

    material = materials{mat_id};

    fprintf('\n')
    fprintf('=====================================================\n')
    fprintf('MATERIAL ACTUAL: %s\n',upper(material))
    fprintf('=====================================================\n')


    %% ====================================================================
    % 2. CARGA DE PARÁMETROS
    % ====================================================================

    params

    required_params = { ...
    'L','T','dx','dt', ...
    'alpha','Nmc', ...
    'sigma_values', ...
    'x_center', ...
    'init_amp', ...
    'init_width', ...
    'profile_type'};

for k = 1:length(required_params)

    if ~exist(required_params{k},'var')

        error(['Falta parametro: ',required_params{k}])

    end

end
    fprintf('\n=== Simulación: Ecuación de Calor 1D ===\n')

    fprintf('Dominio espacial: x ∈ [0, %.3g]\n',L)

    fprintf('Tiempo final: T = %.3g\n',T)

    fprintf('dx = %.3g\n',dx)

    fprintf('dt = %.3g\n',dt)

    fprintf('Monte Carlo = %d\n\n',Nmc)


    %% ====================================================================
    % 3. CONSTRUCCIÓN DE LA MALLA
    % ====================================================================

    grid = build_grid(L,T,dx,dt);


    %% ====================================================================
    % 4. CONDICIÓN INICIAL
    % ====================================================================

    U0 = init_condition( ...
            grid.x, ...
            x_center, ...
            init_amp, ...
            init_width, ...
            profile_type);


    %% ====================================================================
    % 5. OPERADOR LAPLACIANO
    % ====================================================================

    Ah = assemble_Ah( ...
            grid.Nx, ...
            grid.dx, ...
            alpha);


    %% ====================================================================
    % 6. SOLUCIÓN DETERMINISTA
    % ====================================================================

    fprintf('Resolviendo modelo determinista...\n')

    tic

   [detU,detMetrics] = solver_deterministic_CN( ...
                        U0, ...
                        Ah, ...
                        grid);

    t_det = toc;

    fprintf('✔ Determinista completado %.2f s\n\n',t_det)


    %% ====================================================================
    % 7. OPCIONES MONTE CARLO
    % ====================================================================

    opts.store_all = store_all_realizations;

    opts.rngSeed = rng_seed;

    opts.parallel = use_parallel;


    %% ====================================================================
    % 8. ANÁLISIS PARAMÉTRICO
    % ====================================================================

    fprintf('Iniciando análisis paramétrico\n\n')

    tic

    results = struct([]);


    for i = 1:length(sigma_values)

        sigma = sigma_values(i);

        fprintf( ...
            'Simulación %d/%d | sigma=%.3f\n', ...
            i, ...
            length(sigma_values), ...
            sigma);


        %% ---------------------------------------------------------------
        % MONTE CARLO
        %% ---------------------------------------------------------------

        stats = montecarlo_runner( ...
                U0, ...
                Ah, ...
                grid, ...
                sigma, ...
                Nmc, ...
                opts);


        %% ---------------------------------------------------------------
        % RMSE TEMPORAL
        %% ---------------------------------------------------------------

        rmse_t = sqrt( ...
                    mean( ...
                    (stats.mean - detU).^2, ...
                    1));


        %% ---------------------------------------------------------------
        % ENERGÍA TÉRMICA
        %% ---------------------------------------------------------------

        energy = sum( ...
                    stats.mean.^2, ...
                    1) * grid.dx;


        %% ---------------------------------------------------------------
        % TIEMPO DE ESTABILIZACIÓN
        %% ---------------------------------------------------------------

        delta_t = max( ...
                    abs(diff(stats.mean,1,2)), ...
                    [], ...
                    1);

        tol_stab = stabilization_tolerance;

        idx = find(delta_t < tol_stab,1);

        if isempty(idx)

            stabilization_time = T;

        else

            stabilization_time = grid.t(idx);

        end


        %% ---------------------------------------------------------------
        % ALMACENAMIENTO
        %% ---------------------------------------------------------------

        results(i).material = material;

        results(i).alpha = alpha;

        results(i).sigma = sigma;

        results(i).stats = stats;

        results(i).rmse_t = rmse_t;

        results(i).energy = energy;

        results(i).RMSE_final = rmse_t(end);

        results(i).var_max = max(stats.var(:));

        results(i).var_mean = mean(stats.var(:));

        results(i).energy_final = energy(end);

        results(i).stabilization_time = stabilization_time;

    end


    t_mc = toc;

    fprintf('\n✔ Simulaciones completadas %.2f s\n\n',t_mc)


    %% ====================================================================
    % 9. TABLA RESUMEN
    % ====================================================================

    fprintf('\n')

    fprintf('===============================================================\n')

    fprintf(' Sigma      RMSE       Var_max      Energia     Estabilizacion\n')

    fprintf('===============================================================\n')


    for i = 1:length(results)

        fprintf('%6.3f   %10.3e  %10.3e  %10.3e  %10.3e\n', ...
        results(i).sigma, ...
        results(i).RMSE_final, ...
        results(i).var_max, ...
        results(i).energy_final, ...
        results(i).stabilization_time);

    end

    fprintf('===============================================================\n')


    %% ====================================================================
    % 10. VISUALIZACIONES
    % ====================================================================

    selected = [1 3 5];

    selected = selected(selected <= length(results));


    for i = selected

        try

            postprocess_plot( ...
                    grid, ...
                    detU, ...
                    results(i).stats, ...
                    results(i).sigma, ...
                    alpha, ...
                    save_results, ...
                    [material,'_sigma_',num2str(i)]);

        catch ME

            warning( ...
            'Error en postprocess_plot: %s', ...
            ME.message);

        end

    end


    %% ====================================================================
    % 11. RMSE vs SIGMA
    % ====================================================================

    fig1 = figure('Name','RMSE_vs_Sigma');

    semilogy( ...
        [results.sigma], ...
        [results.RMSE_final], ...
        '-o', ...
        'LineWidth',2, ...
        'MarkerSize',8)

    grid on

    xlabel('\sigma','FontSize',12)

    ylabel('RMSE','FontSize',12)

    title( ...
    ['Sensibilidad al ruido - ',material], ...
    'FontSize',13)

    set(gca,'FontSize',11)

    box on


    %% ====================================================================
    % 12. VARIANZA vs SIGMA
    % ====================================================================

    fig2 = figure('Name','Varianza_vs_Sigma');

    plot( ...
        [results.sigma], ...
        [results.var_mean], ...
        '-o', ...
        'LineWidth',2, ...
        'MarkerSize',8)

    grid on

    xlabel('\sigma','FontSize',12)

    ylabel('Varianza promedio','FontSize',12)

    title( ...
    ['Incertidumbre térmica - ',material], ...
    'FontSize',13)

    set(gca,'FontSize',11)

    box on


    %% ====================================================================
    % 13. ENERGÍA TÉRMICA
    % ====================================================================

    fig3 = figure('Name','Energia');

    hold on

    for i = selected

        plot( ...
            grid.t, ...
            results(i).energy, ...
            'LineWidth',2)

    end

    grid on

    xlabel('t','FontSize',12)

    ylabel('Energía térmica','FontSize',12)

    title( ...
    ['Disipación energética - ',material], ...
    'FontSize',13)

     legend_strings = cell(1,length(selected));
    
    for k = 1:length(selected)
    
        legend_strings{k} = sprintf( ...
            '\\sigma = %.2f', ...
            results(selected(k)).sigma);
    
    end

legend(legend_strings,'Location','best')

    set(gca,'FontSize',11)

    box on


    %% ====================================================================
    % 14. AJUSTE LINEAL RMSE
    % ====================================================================
    if length(results) >= 2
    
        p = polyfit( ...
                [results.sigma], ...
                [results.RMSE_final], ...
                1);
    
    else
    
        p = [NaN NaN];
    
    end

    rmse_values = [results.RMSE_final];

    sigma_vals  = [results.sigma];
    R = corrcoef(sigma_vals,rmse_values);
    if numel(R) >= 4

    corr_sigma_rmse = R(1,2);

    else
    
        corr_sigma_rmse = NaN;
    
    end

       fprintf('\n')

    fprintf('========================================\n')

    fprintf('Modelo lineal RMSE:\n')

    fprintf('RMSE = %.4e*sigma + %.4e\n', ...
    p(1), ...
    p(2))

    fprintf('\n')

    fprintf('Pendiente sensibilidad = %.4e\n',p(1))

    fprintf('Correlacion sigma-RMSE = %.4f\n', ...
    corr_sigma_rmse)

    fprintf('========================================\n')


    %% ====================================================================
    % 15. FIGURA MULTIPANEL
    % ====================================================================

    fig4 = figure('Name','Multipanel');

    tiledlayout(2,2,'Padding','compact','TileSpacing','compact')


    % PANEL 1
    nexttile

    plot( ...
        [results.sigma], ...
        [results.RMSE_final], ...
        '-o', ...
        'LineWidth',2)

    grid on

    xlabel('\sigma')

    ylabel('RMSE')

    title('Sensibilidad al ruido')


    % PANEL 2
    nexttile

    plot( ...
        [results.sigma], ...
        [results.var_mean], ...
        '-s', ...
        'LineWidth',2)

    grid on

    xlabel('\sigma')

    ylabel('Varianza')

    title('Incertidumbre térmica')


    % PANEL 3
    nexttile

    hold on

    for ii = selected

        plot( ...
            grid.t, ...
            results(ii).energy, ...
            'LineWidth',2)

    end

    grid on

    xlabel('t')

    ylabel('Energía')

    title('Disipación energética')


    % PANEL 4
    nexttile

    plot( ...
        grid.t, ...
        results(end).rmse_t, ...
        'LineWidth',2)

    grid on

    xlabel('t')

    ylabel('RMSE')

    title('RMSE temporal')


    sgtitle( ...
    ['Resumen global - ',upper(material)], ...
    'FontSize',14)


   %% ====================================================================
% 16. EXPORTACIÓN SEGURA
% ====================================================================

if save_results

    figs = findobj('Type','figure');

    for k = 1:length(figs)

        try

            fig = figs(k);

            if isempty(fig)
                continue
            end

            if ~isvalid(fig)
                continue
            end

            ax = findall(fig,'type','axes');

            if isempty(ax)
                continue
            end

            drawnow

            filename = sprintf( ...
                '%s_fig_%02d.png', ...
                material, ...
                k);

            try

            exportgraphics( ...
            ax(1), ...
            filename, ...
            'Resolution',300);
            
            catch
            
                saveas(fig,filename);
            
            end

            fprintf('Figura exportada: %s\n',filename);

        catch ME

            warning( ...
            'No se pudo exportar figura %d: %s', ...
            k, ...
            ME.message);

        end

    end

end

    %% ====================================================================
    % 17. GUARDADO RESULTADOS
    % ====================================================================

    if save_results

        try

            save( ...
            [material,'_',results_filename], ...
            'grid', ...
            'detU', ...
            'results', ...
            'alpha', ...
            'Nmc');

            fprintf('\nResultados guardados:\n')

            fprintf('%s\n', ...
            [material,'_',results_filename])

        catch ME

            warning(ME.message)

        end

    end


    %% ====================================================================
    % 18. ALMACENAMIENTO GLOBAL
    % ====================================================================

    all_materials_results.(material) = results;

end


%% ========================================================================
% 19. COMPARACIÓN GLOBAL RMSE vs SIGMA
% ========================================================================

figure('Name','Comparacion_Global')

hold on


semilogy( ...
    [all_materials_results.aluminium.sigma], ...
    [all_materials_results.aluminium.RMSE_final], ...
    '-o', ...
    'LineWidth',2, ...
    'MarkerSize',8)


semilogy( ...
    [all_materials_results.stainless_steel.sigma], ...
    [all_materials_results.stainless_steel.RMSE_final], ...
    '-s', ...
    'LineWidth',2, ...
    'MarkerSize',8)


semilogy( ...
    [all_materials_results.wood.sigma], ...
    [all_materials_results.wood.RMSE_final], ...
    '-d', ...
    'LineWidth',2, ...
    'MarkerSize',8)


grid on

box on


xlabel('\sigma','FontSize',12)

ylabel('RMSE final','FontSize',12)

title( ...
'Comparación global RMSE vs intensidad del ruido', ...
'FontSize',13)


legend( ...
'Aluminium', ...
'Stainless steel', ...
'Wood', ...
'Location','northwest')


set(gca,'FontSize',11)


%% ========================================================================
% 20. FIN
% ========================================================================

fprintf('\n=== FIN DE LA SIMULACIÓN ===\n')