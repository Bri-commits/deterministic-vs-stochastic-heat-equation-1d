function stats = montecarlo_runner(U0,Ah,grid,sigma,Nmc,opts)

% =========================================================================
% MONTECARLO_RUNNER
% =========================================================================
%
% Ejecuta múltiples realizaciones Monte Carlo para:
%
%   du = alpha*u_xx dt + sigma dW
%
% usando:
%
%   solver_stochastic_EM
%
% =========================================================================


%% ========================================================================
% 1. VALIDACIÓN DE ENTRADAS
% ========================================================================

if nargin < 5 || isempty(Nmc)

    Nmc = 100;

end


if nargin < 6 || isempty(opts)

    opts = struct();

end
if ~isstruct(opts)

    error('opts debe ser una estructura.')

end

if ~isfield(opts,'store_all')

    opts.store_all = false;

end


if ~isfield(opts,'rngSeed')

    opts.rngSeed = [];

end


if Nmc <= 0 || floor(Nmc) ~= Nmc

    error('Nmc debe ser un entero positivo.')

end




if ~(isnumeric(sigma) && isscalar(sigma) ...
        && isfinite(sigma) && sigma >= 0)

    error('sigma debe ser un escalar finito no negativo.')

end

required_fields = { ...
    'Nx','Nt','dx','dt', ...
    'inner_idx','x','t'};

for i = 1:length(required_fields)

    if ~isfield(grid,required_fields{i})

        error(['Falta grid.',required_fields{i}])

    end

end
Nx = grid.Nx;

Nt = grid.Nt;
dx = grid.dx;
%% ========================================================================
% 2. PREALOCACIÓN
% ========================================================================

mean_acc = zeros(Nx,Nt);

M2 = zeros(Nx,Nt);

count = 0;


%% ========================================================================
% 3. ENERGÍA
% ========================================================================

energy_time_acc = zeros(1,Nt);


%% ========================================================================
% 4. ALMACENAMIENTO OPCIONAL
% ========================================================================

if opts.store_all

    allU = zeros(Nx,Nt,Nmc);

else

    allU = [];

end


%% ========================================================================
% 5. BUCLE MONTE CARLO
% ========================================================================

for k = 1:Nmc


    %% --------------------------------------------------------------------
    % SEMILLA
    % ---------------------------------------------------------------------

    if ~isempty(opts.rngSeed)

        seed = opts.rngSeed + k;

    else

        seed = [];

    end


    %% --------------------------------------------------------------------
    % RESOLVER SPDE
    % ---------------------------------------------------------------------

    U = solver_stochastic_EM( ...
            U0, ...
            Ah, ...
            grid, ...
            sigma, ...
            seed);
    if any(~isfinite(U(:)))

    warning('Realización no finita detectada en Monte Carlo.')

end

    %% --------------------------------------------------------------------
    % ALGORITMO DE WELFORD
    % ---------------------------------------------------------------------
    % Permite calcular media y varianza de forma estable
    % numéricamente sin almacenar todas las realizaciones.
    count = count + 1;


    delta = U - mean_acc;

    mean_acc = mean_acc + delta/count;

    delta2 = U - mean_acc;

    M2 = M2 + delta .* delta2;


    %% --------------------------------------------------------------------
    % ENERGÍA TÉRMICA
    % ---------------------------------------------------------------------

    energy_k = sum(U.^2,1) * dx;

    energy_time_acc = energy_time_acc + energy_k;


    %% --------------------------------------------------------------------
    % GUARDAR REALIZACIONES
    % ---------------------------------------------------------------------

    if opts.store_all

        allU(:,:,k) = U;

    end

end


%% ========================================================================
% 6. VARIANZA
% ========================================================================

if count > 1

    variance = M2/(count-1);

    % Evitar pequeños valores negativos producidos
    % por redondeo numérico
    variance = max(variance,0);

else

    variance = zeros(Nx,Nt);

end

%% ========================================================================
% 7. DESVIACIÓN ESTÁNDAR
% ========================================================================

std_dev = sqrt(variance);
std_dev(~isfinite(std_dev)) = 0;

%% ========================================================================
% 8. BANDAS DE INCERTIDUMBRE
% ========================================================================
% Bandas empíricas de dispersión:
%
%     mean ± 2 std
%
% utilizadas para visualizar variabilidad
% estadística de las realizaciones.
upper_band = mean_acc + 2*std_dev;

lower_band = mean_acc - 2*std_dev;


%% ========================================================================
% 9. INTERVALOS DE CONFIANZA 95%
% ========================================================================
% Basados en aproximación gaussiana:
%
%   mean ± 1.96 * std/sqrt(Nmc)
%
conf95 = 1.96 * std_dev / sqrt(Nmc);

CI_upper = mean_acc + conf95;

CI_lower = mean_acc - conf95;


%% ========================================================================
% 10. COEFICIENTE DE VARIACIÓN
% ========================================================================

cv = std_dev ./ (abs(mean_acc) + 1e-12);

% El pequeño término 1e-12 evita divisiones
% por cero cuando la media es cercana a cero.
% Limitar valores absurdamente grandes
cv(cv > 1e6) = 1e6;


%% ========================================================================
% 11. ENERGÍA PROMEDIO
% ========================================================================

mean_energy_time = energy_time_acc / Nmc;

%% ========================================================================
% 11.b ENERGÍA FINAL PROMEDIO
% ========================================================================

final_energy_mean = sum(mean_acc(:,end).^2) * dx;
%% ========================================================================
% 12. MÉTRICAS GLOBALES
% ========================================================================

max_variance  = max(variance(:));

mean_variance = mean(variance(:));

max_std       = max(std_dev(:));

mean_std      = mean(std_dev(:));

max_cv        = max(cv(:));

mean_cv       = mean(cv(:));


%% ========================================================================
% 13. SKEWNESS Y KURTOSIS
% ========================================================================
%
% Estas métricas requieren almacenar todas las realizaciones.
% Si store_all = false, no se calculan para ahorrar memoria.
%
% ========================================================================

if opts.store_all

    reshaped_data = reshape(allU,Nx*Nt,Nmc);

    skewness_values = skewness(reshaped_data,0,2);

    kurtosis_values = kurtosis(reshaped_data,0,2);

    skewness_values = skewness_values(isfinite(skewness_values));

    kurtosis_values = kurtosis_values(isfinite(kurtosis_values));

    skewness_global = mean(skewness_values);

    kurtosis_global = mean(kurtosis_values);

else

    skewness_global = [];
    kurtosis_global = [];

end

%% ========================================================================
% 14. VALIDACIONES NUMÉRICAS
% ========================================================================

if any(isnan(mean_acc(:)))
    warning('NaNs detectados en media Monte Carlo.')

end


if any(isinf(mean_acc(:)))

    warning('Inf detectados en media Monte Carlo.')

end


%% ========================================================================
% 15. EMPAQUETAR RESULTADOS
% ========================================================================

stats.mean = mean_acc;

stats.var = variance;

stats.std = std_dev;

stats.upper = upper_band;

stats.lower = lower_band;

stats.CI_upper = CI_upper;

stats.CI_lower = CI_lower;

stats.cv = cv;

stats.mean_energy_time = mean_energy_time;
stats.final_energy_mean = final_energy_mean;
stats.max_var = max_variance;

stats.mean_var = mean_variance;

stats.max_std = max_std;

stats.mean_std = mean_std;

stats.max_cv = max_cv;

stats.mean_cv = mean_cv;

stats.skewness = skewness_global;

stats.kurtosis = kurtosis_global;

stats.count = count;

stats.allU = allU;


%% ========================================================================
% 16. RESUMEN EN CONSOLA
% ========================================================================

fprintf('\n');

fprintf('====================================\n');

fprintf('MONTE CARLO COMPLETADO\n');

fprintf('====================================\n');

fprintf('Realizaciones = %d\n',Nmc);

fprintf('sigma = %.3f\n',sigma);

fprintf('\n');

fprintf('Varianza máxima = %.6e\n',max_variance);

fprintf('Varianza media  = %.6e\n',mean_variance);

fprintf('\n');

fprintf('Std máxima = %.6e\n',max_std);

fprintf('Std media  = %.6e\n',mean_std);

fprintf('\n');

fprintf('CV máximo = %.6e\n',max_cv);

fprintf('CV medio  = %.6e\n',mean_cv);

fprintf('\n');
fprintf('Energía final promedio = %.6e\n', ...
        final_energy_mean);
if ~isempty(skewness_global)

    fprintf('Skewness global = %.6f\n',skewness_global);
    fprintf('Kurtosis global = %.6f\n',kurtosis_global);

else

    fprintf('Skewness global = no calculado\n');
    fprintf('Kurtosis global = no calculado\n');

end