% =========================================================================
% run_all_validation.m
% =========================================================================
%
% VALIDACIÓN NUMÉRICA COMPLETA
%
% ECUACIÓN DE CALOR 1D
% DETERMINISTA Y ESTOCÁSTICA
%
% Este script ejecuta automáticamente todos los estudios de
% validación utilizados en el artículo científico.
%
% -------------------------------------------------------------------------
% VALIDACIONES NUMÉRICAS
% -------------------------------------------------------------------------
%
% [1] Convergencia espacial
%
%       Error = O(dx²)
%
% [2] Convergencia temporal (Crank-Nicolson)
%
%       Error = O(dt²)
%
% [3] Convergencia fuerte y débil
%
%       Error fuerte ~ O(dt^(1/2))
%
%       Error débil  ~ O(dt)
%
% [4] Intervalos de confianza Monte Carlo
%
%       IC95% ~ O(1/sqrt(Nmc))
%
% -------------------------------------------------------------------------
% ANÁLISIS ESTADÍSTICOS COMPLEMENTARIOS (opcionales)
% -------------------------------------------------------------------------
%
% [5] Perfiles de varianza
%
% [6] Gaussianidad
%
%       - Skewness
%       - Kurtosis
%
% =========================================================================

clear
close all
clc

fprintf('\n')
fprintf('=============================================================\n')
fprintf('VALIDACION NUMERICA COMPLETA\n')
fprintf('ECUACION DE CALOR DETERMINISTA Y ESTOCASTICA\n')
fprintf('=============================================================\n')

%% ========================================================================
% 1. CONVERGENCIA ESPACIAL
% ========================================================================

fprintf('\n')
fprintf('-------------------------------------------------------------\n')
fprintf('1. ESTUDIO DE CONVERGENCIA ESPACIAL\n')
fprintf('-------------------------------------------------------------\n')

try

    study_spatial_convergence

    fprintf('\n')
    fprintf('Convergencia espacial completada.\n')

catch ME

    fprintf('\n')
    fprintf('ERROR en study_spatial_convergence\n')
    fprintf('%s\n',ME.message)

end


%% ========================================================================
% 2. CONVERGENCIA TEMPORAL
% ========================================================================

fprintf('\n')
fprintf('-------------------------------------------------------------\n')
fprintf('2. ESTUDIO DE CONVERGENCIA TEMPORAL\n')
fprintf('-------------------------------------------------------------\n')

try

    study_temporal_convergence

    fprintf('\n')
    fprintf('Convergencia temporal completada.\n')

catch ME

    fprintf('\n')
    fprintf('ERROR en study_temporal_convergence\n')
    fprintf('%s\n',ME.message)

end


%% ========================================================================
% 3. CONVERGENCIA FUERTE Y DÉBIL
% ========================================================================

fprintf('\n')
fprintf('-------------------------------------------------------------\n')
fprintf('3. CONVERGENCIA FUERTE Y DEBIL\n')
fprintf('-------------------------------------------------------------\n')

try

    study_strong_weak_convergence

    fprintf('\n')
    fprintf('Convergencia fuerte y débil completada.\n')

catch ME

    fprintf('\n')
    fprintf('ERROR en study_strong_weak_convergence\n')
    fprintf('%s\n',ME.message)

end


%% ========================================================================
% 4. INTERVALOS DE CONFIANZA MONTE CARLO
% ========================================================================

fprintf('\n')
fprintf('-------------------------------------------------------------\n')
fprintf('4. INTERVALOS DE CONFIANZA MONTE CARLO\n')
fprintf('-------------------------------------------------------------\n')

if exist('study_confidence_intervals','file')

    try

        study_confidence_intervals

        fprintf('\n')
        fprintf('Estudio de intervalos de confianza completado.\n')

    catch ME

        fprintf('\n')
        fprintf('ERROR en study_confidence_intervals\n')
        fprintf('%s\n',ME.message)

    end

else

    fprintf('\n')
    fprintf('study_confidence_intervals.m no encontrado.\n')

end


%% ========================================================================
% 5. PERFILES DE VARIANZA (OPCIONAL)
% ========================================================================

fprintf('\n')
fprintf('-------------------------------------------------------------\n')
fprintf('5. PERFILES DE VARIANZA\n')
fprintf('-------------------------------------------------------------\n')

if exist('study_variance_profiles','file')

    try

        study_variance_profiles

        fprintf('\n')
        fprintf('Perfiles de varianza completados.\n')

    catch ME

        fprintf('\n')
        fprintf('ERROR en study_variance_profiles\n')
        fprintf('%s\n',ME.message)

    end

else

    fprintf('\n')
    fprintf('study_variance_profiles.m no encontrado.\n')

end


%% ========================================================================
% 6. GAUSSIANIDAD (OPCIONAL)
% ========================================================================

fprintf('\n')
fprintf('-------------------------------------------------------------\n')
fprintf('6. ANALISIS DE GAUSSIANIDAD\n')
fprintf('-------------------------------------------------------------\n')

if exist('study_gaussianity','file')

    try

        study_gaussianity

        fprintf('\n')
        fprintf('Análisis de gaussianidad completado.\n')

    catch ME

        fprintf('\n')
        fprintf('ERROR en study_gaussianity\n')
        fprintf('%s\n',ME.message)

    end

else

    fprintf('\n')
    fprintf('study_gaussianity.m no encontrado.\n')

end


%% ========================================================================
% RESUMEN FINAL
% ========================================================================

fprintf('\n')
fprintf('=============================================================\n')
fprintf('VALIDACION NUMERICA FINALIZADA\n')
fprintf('=============================================================\n')
fprintf('\n')

fprintf('Estudios principales:\n')
fprintf('\n')
fprintf('  [OK] Convergencia espacial\n')
fprintf('  [OK] Convergencia temporal\n')
fprintf('  [OK] Convergencia fuerte\n')
fprintf('  [OK] Convergencia debil\n')
fprintf('  [OK] Intervalos de confianza\n')

fprintf('\n')

fprintf('Estudios complementarios:\n')
fprintf('\n')
fprintf('  [*] Perfiles de varianza\n')
fprintf('  [*] Gaussianidad\n')

fprintf('\n')
fprintf('La validacion numerica del articulo ha concluido.\n')
fprintf('=============================================================\n')
save('validation_results.mat')
