function Uexact = exact_solution_heat(x,t,alpha,amp,L)

% =========================================================================
% exact_solution_heat
% =========================================================================
%
% SOLUCIÓN ANALÍTICA DE LA ECUACIÓN DEL CALOR 1D
%
%     u_t = alpha*u_xx
%
% con:
%
%     u(x,0) = amp*sin(pi*x/L)
%
% y condiciones de frontera:
%
%     u(0,t) = 0
%     u(L,t) = 0
%
%
% SOLUCIÓN EXACTA:
%
% u(x,t)
% =
% amp * exp(-alpha*(pi/L)^2*t) * sin(pi*x/L)
%
% =========================================================================
%
% ENTRADAS
%
% x      -> vector espacial
%
% t      -> vector temporal
%
% alpha  -> difusividad térmica
%
% amp    -> amplitud inicial
%
% L      -> longitud del dominio
%
%
% SALIDA
%
% Uexact -> matriz Nx x Nt
%
% =========================================================================


%% ========================================================================
% 1. VALIDACIONES
% ========================================================================

if nargin < 5

    error('Se requieren x, t, alpha, amp y L')

end


if alpha <= 0

    error('alpha debe ser positivo')

end


if L <= 0

    error('L debe ser positivo')

end


%% ========================================================================
% 2. ASEGURAR VECTORES COLUMNA
% ========================================================================

x = x(:);

t = t(:);


Nx = length(x);

Nt = length(t);


%% ========================================================================
% 3. PREALOCACIÓN
% ========================================================================

Uexact = zeros(Nx,Nt);


%% ========================================================================
% 4. FACTOR ESPACIAL
% ========================================================================
%
% Esta parte NO depende del tiempo
%
% sin(pi*x/L)
%
% ========================================================================

spatial_mode = sin(pi*x/L);


%% ========================================================================
% 5. FACTOR TEMPORAL
% ========================================================================
%
% Esta parte representa la disipación térmica:
%
% exp(-alpha*(pi/L)^2*t)
%
% ========================================================================

temporal_decay = exp( ...
                    -alpha*(pi/L)^2*t );


%% ========================================================================
% 6. CONSTRUCCIÓN DE LA SOLUCIÓN
% ========================================================================

for n = 1:Nt

    Uexact(:,n) = ...
        amp * temporal_decay(n) * spatial_mode;

end


%% ========================================================================
% 7. VALIDACIÓN FINAL
% ========================================================================

if any(isnan(Uexact),'all')

    error('NaNs detectados en solución exacta')

end


if any(isinf(Uexact),'all')

    error('Infs detectados en solución exacta')

end


%% ========================================================================
% 8. INFORMACIÓN
% ========================================================================

fprintf('\n')

fprintf('====================================\n')

fprintf('SOLUCIÓN ANALÍTICA GENERADA\n')

fprintf('====================================\n')

fprintf('Nx = %d\n',Nx)

fprintf('Nt = %d\n',Nt)

fprintf('alpha = %.6e\n',alpha)

fprintf('====================================\n')


end