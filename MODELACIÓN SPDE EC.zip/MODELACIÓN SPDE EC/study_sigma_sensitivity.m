% =========================================================================
% study_sigma_sensitivity.m
% =========================================================================
%
% ANALISIS DE SENSIBILIDAD AL RUIDO ESTOCASTICO
%
% Ecuacion:
%
%    du = alpha*u_xx dt + sigma dW
%
% Objetivos:
%
% 1. Cuantificar el efecto de sigma
% 2. Comparar con la solucion determinista
% 3. Analizar crecimiento de la varianza
% 4. Verificar leyes de escala:
%
%       RMSE     ~ sigma
%       Var(u)   ~ sigma^2
%
% =========================================================================

clear
clc
close all

fprintf('\n')
fprintf('====================================\n')
fprintf('SENSIBILIDAD AL RUIDO ESTOCASTICO\n')
fprintf('====================================\n')

%% ==========================================================
% PARAMETROS
% ===========================================================

L = 1;
T = 0.5;

alpha = 1;

dx = 0.01;
dt = 1e-4;

Nmc = 1000;

sigma_values = [0.01 0.05 0.10 0.20 0.50 1.00];

rng_seed = 1234;

%% ==========================================================
% MALLA
% ===========================================================

grid = build_grid(L,T,dx,dt);

%% ==========================================================
% CONDICION INICIAL
% ===========================================================

x = grid.x;

U0 = sin(pi*x);

%% ==========================================================
% OPERADOR ESPACIAL
% ===========================================================

Ah = assemble_Ah( ...
        grid.Nx,...
        grid.dx,...
        alpha);

%% ==========================================================
% SOLUCION DETERMINISTA
% ===========================================================

detU = solver_deterministic_CN( ...
        U0,...
        Ah,...
        grid);

EnergyDet = ...
    sum(detU(:,end).^2)*grid.dx;

%% ==========================================================
% OPCIONES MONTE CARLO
% ===========================================================

opts.store_all = false;

opts.parallel = false;

opts.rngSeed = rng_seed;

%% ==========================================================
% PREALOCACION
% ===========================================================

nSigma = length(sigma_values);

RMSE_final     = zeros(nSigma,1);

RelativeError  = zeros(nSigma,1);

VarMean        = zeros(nSigma,1);

VarMax         = zeros(nSigma,1);

StdMax         = zeros(nSigma,1);

EnergyFinal    = zeros(nSigma,1);

EnergyLoss     = zeros(nSigma,1);

CVmean         = zeros(nSigma,1);

%% ==========================================================
% BUCLE SOBRE SIGMA
% ===========================================================

for k = 1:nSigma

    sigma = sigma_values(k);

    fprintf('\n')
    fprintf('Caso %d de %d\n',k,nSigma)
    fprintf('sigma = %.2f\n',sigma)

    stats = montecarlo_runner( ...
            U0,...
            Ah,...
            grid,...
            sigma,...
            Nmc,...
            opts);

    %% ------------------------------------------------------
    % Error respecto a la solucion determinista
    % -------------------------------------------------------

    RMSE_final(k) = sqrt( ...
        mean( ...
        (stats.mean(:,end)-detU(:,end)).^2 ) );

    RelativeError(k) = ...
        norm(stats.mean(:,end)-detU(:,end),2) ...
        / norm(detU(:,end),2);

    %% ------------------------------------------------------
    % Varianza
    % -------------------------------------------------------

    VarMax(k) = max(stats.var(:));

    VarMean(k) = mean(stats.var(:));

    %% ------------------------------------------------------
    % Desviacion estandar
    % -------------------------------------------------------

    StdMax(k) = max(stats.std(:));

    %% ------------------------------------------------------
    % Energia
    % -------------------------------------------------------

    EnergyFinal(k) = ...
        sum(stats.mean(:,end).^2)*grid.dx;

    EnergyLoss(k) = ...
        abs(EnergyFinal(k)-EnergyDet)/EnergyDet;

    %% ------------------------------------------------------
    % Coeficiente de variacion
    % -------------------------------------------------------

    cv_aux = stats.cv;

    cv_aux(~isfinite(cv_aux)) = NaN;

    CVmean(k) = mean(cv_aux(:),'omitnan');

end

%% ==========================================================
% TABLA
% ===========================================================

fprintf('\n')

fprintf('==========================================================================\n')
fprintf(' sigma      RMSE      RelError      VarMean      StdMax        Erel\n')
fprintf('==========================================================================\n')

for k = 1:nSigma

    fprintf( ...
'%6.2f   %10.3e   %10.3e   %10.3e   %10.3e   %10.3e\n',...
    sigma_values(k),...
    RMSE_final(k),...
    RelativeError(k),...
    VarMean(k),...
    StdMax(k),...
    EnergyLoss(k));

end

fprintf('==========================================================================\n')

%% ==========================================================
% AJUSTES LOG-LOG
% ===========================================================

pVar = polyfit( ...
        log(sigma_values),...
        log(VarMean'),...
        1);

pRMSE = polyfit( ...
        log(sigma_values),...
        log(RMSE_final'),...
        1);

%% ==========================================================
% FIGURA 1
% RMSE
% ===========================================================

figure

loglog( ...
    sigma_values,...
    RMSE_final,...
    '-o',...
    'LineWidth',2)

grid on

xlabel('\sigma')
ylabel('RMSE')

title('RMSE vs intensidad del ruido')

%% ==========================================================
% FIGURA 2
% VARIANZA
% ===========================================================

figure

loglog( ...
    sigma_values,...
    VarMean,...
    '-s',...
    'LineWidth',2)

grid on

xlabel('\sigma')
ylabel('Varianza promedio')

title('Varianza promedio vs intensidad del ruido')

%% ==========================================================
% FIGURA 3
% LEY DE ESCALA VARIANZA
% ===========================================================

figure

loglog( ...
    sigma_values,...
    VarMean,...
    '-o',...
    'LineWidth',2)

hold on

VarTheory = ...
    VarMean(1) * ...
    (sigma_values/sigma_values(1)).^2;

loglog( ...
    sigma_values,...
    VarTheory,...
    '--',...
    'LineWidth',2)

grid on

xlabel('\sigma')
ylabel('Varianza promedio')

title('Ley de escala Var(u) \propto \sigma^2')

legend( ...
    'Monte Carlo',...
    'Escalamiento teorico',...
    'Location','best')

%% ==========================================================
% FIGURA 4
% LEY DE ESCALA RMSE
% ===========================================================

figure

loglog( ...
    sigma_values,...
    RMSE_final,...
    '-o',...
    'LineWidth',2)

hold on

RMSE_theory = ...
    RMSE_final(1) * ...
    (sigma_values/sigma_values(1));

loglog( ...
    sigma_values,...
    RMSE_theory,...
    '--',...
    'LineWidth',2)

grid on

xlabel('\sigma')
ylabel('RMSE')

title('Ley de escala RMSE \propto \sigma')

legend( ...
    'Monte Carlo',...
    'Escalamiento teorico',...
    'Location','best')

%% ==========================================================
% RESUMEN FINAL
% ===========================================================

fprintf('\n')

fprintf('====================================\n')
fprintf('LEYES DE ESCALA OBSERVADAS\n')
fprintf('====================================\n')

fprintf('\n')

fprintf('Pendiente RMSE vs sigma     = %.6f\n', ...
        pRMSE(1))
fprintf('Teoria RMSE                = 1.000000\n')

fprintf('\n')

fprintf('Pendiente Varianza vs sigma = %.6f\n', ...
        pVar(1))
fprintf('Teoria Varianza            = 2.000000\n')

fprintf('\n')
fprintf('Analisis de sensibilidad completado.\n')