function U0 = init_condition( ...
                    x, ...
                    x_center, ...
                    amp, ...
                    width, ...
                    profile_type)

% =========================================================================
% init_condition
% =========================================================================
%
% CONDICIÓN INICIAL PARA LA ECUACIÓN DE CALOR 1D
%
% Genera distintos perfiles térmicos iniciales:
%
% - gaussiano
% - doble gaussiano
% - uniforme
% - senoidal
%
% SALIDA:
%
% U0 -> vector columna Nx x 1
%
% =========================================================================


%% ========================================================================
% 1. VALIDACIÓN DE ENTRADAS
% ========================================================================

if nargin < 4

    error('Se requieren al menos 4 entradas.')

end


if nargin < 5 || isempty(profile_type)

    profile_type = 'gaussian';

end


if ~isvector(x)

    error('x debe ser un vector.')

end


if width <= 0

    error('width debe ser positivo.')

end


if ~isnumeric(amp)

    error('amp debe ser numérico.')

end


%% ========================================================================
% 2. ASEGURAR VECTOR COLUMNA
% ========================================================================

x = x(:);

Nx = length(x);


%% ========================================================================
% 3. CONSTRUCCIÓN DEL PERFIL
% ========================================================================

switch lower(profile_type)


    %% --------------------------------------------------------------------
    % PERFIL GAUSSIANO
    % ---------------------------------------------------------------------

    case 'gaussian'

        U0 = amp * exp( ...
             -width * (x - x_center).^2 );


    %% --------------------------------------------------------------------
    % DOBLE GAUSSIANA
    % ---------------------------------------------------------------------

    case 'double'

        x1 = 0.30;

        x2 = 0.70;

        U0 = amp * exp( ...
             -width * (x - x1).^2 ) ...
           + amp * exp( ...
             -width * (x - x2).^2 );


    %% --------------------------------------------------------------------
    % PERFIL UNIFORME
    % ---------------------------------------------------------------------

    case 'uniform'

        U0 = amp * ones(Nx,1);


    %% --------------------------------------------------------------------
    % PERFIL SENOIDAL
    % ---------------------------------------------------------------------

    case 'sine'

        L = max(x);

        U0 = amp * sin(pi*x/L);


    %% --------------------------------------------------------------------
    % ERROR
    % ---------------------------------------------------------------------

    otherwise

        error( ...
        'Perfil inicial no reconocido.')

end


%% ========================================================================
% 4. ASEGURAR VECTOR COLUMNA
% ========================================================================

U0 = U0(:);


%% ========================================================================
% 5. CONDICIONES DE FRONTERA
% ========================================================================

U0(1)   = 0;

U0(end) = 0;


%% ========================================================================
% 6. VALIDACIÓN FINAL
% ========================================================================

if length(U0) ~= Nx

    error('Dimensión inconsistente en U0.')

end


if any(isnan(U0))

    error('La condición inicial contiene NaNs.')

end


if any(isinf(U0))

    error('La condición inicial contiene Infs.')

end


%% ========================================================================
% 7. NORMALIZACIÓN OPCIONAL
% ========================================================================
%
% Evita amplitudes excesivas.
%
% Puede comentarse si no se desea.
%
% ========================================================================

maxU = max(abs(U0));

if maxU > 1e6

    warning( ...
    'Condición inicial muy grande; normalizando.')

    U0 = U0 / maxU;

end


end